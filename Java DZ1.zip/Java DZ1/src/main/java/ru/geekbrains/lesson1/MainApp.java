package ru.geekbrains.lesson1;

public class MainApp {
    //    1. Создать пустой проект в IntelliJ IDEA и прописать метод main();
    public static void main(String[] args) {
        //    2. Создать переменные всех пройденных типов данных, и инициализировать их значения;
        byte a = 12;//присвоить значение 12 переменной a
        short b = 12345;// присвоить значение 12345 переменной b
        int c = 123456;// присвоить значение 123456 переменной c
        long d = 92233720;// присвоить значение 92233720 переменной d
        float e = 12.36f;// присвоить значение 12.36f переменной e
        double f = 124.234;// присвоить значение 124.234 переменной f
        char g = '$';// присвоить значение $ переменной g
        boolean h = true;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        System.out.println(h);
        System.out.println(number(3.2f, 4.2f, 6.2f, 7.2f));
        boolean number10number20 = numbers10numbers20(10,8);
        System.out.println(number10number20);
        System.out.println(a < 0 ? "-" : "+");
        System.out.println(sixth(-8));
        seventh("Gregory");
        eighth(2004);
        System.out.println(true);



    }
    //    3. Написать метод вычисляющий выражение a * (b + (c / d)) и возвращающий результат,где a, b, c, d – входные параметры этого метода;
    public static float number(float a, float b, float c, float d) {
        return a * (b + (c / d));
    }
    //    4. Написать метод, принимающий на вход два числа, и проверяющий что их сумма лежит в пределах от 10 до 20(включительно), если да – вернуть true, в противном случае – false;
    public static boolean numbers10numbers20(int x, int z) {
        return (10 <= x + z) && (x + z <= 20);
    }
    //    5. Написать метод, которому в качестве параметра передается целое число, метод должен напечатать в консоль положительное ли число передали, или отрицательное; Замечание: ноль считаем положительным числом.
    public static void fifth(int a){


    }


    //    6. Написать метод, которому в качестве параметра передается целое число, метод должен вернуть true, если число отрицательное;
    public static boolean sixth(int i){
        return i < 0;

    }
    //    7. Написать метод, которому в качестве параметра передается строка, обозначающая имя, метод должен вывести в консоль сообщение «Привет, указанное_имя!»;
    public static void seventh(String Gregory){
        System.out.println("Привет,"+Gregory+"!");
    }


    //    8. * Написать метод, который определяет является ли год високосным, и выводит сообщение в консоль. Каждый 4-й год является високосным, кроме каждого 100-го, при этом каждый 400-й – високосный.
    public static boolean eighth(int year){
        return year % 100 != 0 && year % 4 == 0 || year % 400 ==0;
    }
    }